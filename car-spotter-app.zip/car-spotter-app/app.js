import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import { getFirestore, collection, addDoc, getDocs, query, orderBy, serverTimestamp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js';

// Firebase project settings: copy your project's web config here (see README.md).
const firebaseConfig = {
  apiKey: 'YOUR_API_KEY', authDomain: 'YOUR_PROJECT.firebaseapp.com',
  projectId: 'YOUR_PROJECT_ID', storageBucket: 'YOUR_PROJECT.appspot.com',
  messagingSenderId: 'YOUR_MESSAGING_SENDER_ID', appId: 'YOUR_APP_ID'
};
const firebaseReady = !Object.values(firebaseConfig).some(v => String(v).startsWith('YOUR_'));
let auth, db, storage, currentUser = null, vehicles = [], slideIndex = 0;
if (firebaseReady) { const app = initializeApp(firebaseConfig); auth = getAuth(app); db = getFirestore(app); storage = getStorage(app); }

const catalog = {
 'Mercedes-Benz':['A-Klasse','C-Klasse','E-Klasse','S-Klasse','SL','SLS AMG','AMG GT','AMG C 63','AMG E 63','AMG ONE'],
 'Porsche':['911 Carrera','911 Carrera GTS','911 Turbo S','911 GT3','911 GT3 RS','911 S/T','911 GT2 RS','918 Spyder','Taycan'],
 'BMW':['1er','3er','5er','7er','M2','M3','M4','M5','M8','XM'],
 'Ferrari':['488 GTB','488 Pista','458 Italia','F8 Tributo','296 GTB','812 Superfast','SF90 Stradale','LaFerrari'],
 'Lamborghini':['Huracán','Aventador','Revuelto','Urus','Gallardo','Murciélago'],
 'McLaren':['570S','600LT','720S','750S','765LT','Artura','P1','Senna'],
 'Koenigsegg':['Jesko','Jesko Absolut','Agera RS','Regera','Gemera','CC850'],
 'Bugatti':['Veyron','Chiron','Chiron Super Sport','Divo','Bolide','Tourbillon'],
 'Audi':['A3','A4','A6','RS3','RS4','RS6','R8'], 'Volkswagen':['Golf','Golf GTI','Golf R','Passat','Arteon'],
 'Toyota':['Supra','GR Yaris','GR86','Land Cruiser'], 'Nissan':['GT-R','GT-R Nismo','370Z','400Z'],
 'Ford':['Mustang','Mustang Shelby GT500','GT','Focus RS'], 'Chevrolet':['Corvette C8','Camaro ZL1']
};
const rarityRules = [
 {match:/jesko|agera rs|cc850|bolide|tourbillon|divo|laferrari|p1|senna|918 spyder|amg one|s\/t|gt2 rs/i,rarity:'LEGENDÄR',key:'legendary'},
 {match:/gt3 rs|gt3|488 pista|765lt|812|sf90|revuelto|aventador|r8|gt-r nismo|shelby gt500/i,rarity:'EPISCH',key:'epic'},
 {match:/amg|m[23458]|rs[346]|turbo s|720s|750s|600lt|huracán|corvette|supra|mustang/i,rarity:'SELTEN',key:'rare'}
];
function getRarity(model){return rarityRules.find(r=>r.match.test(model))||{rarity:'GEWÖHNLICH',key:'common'};}
const $=id=>document.getElementById(id);
function showView(name){document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));$(name+'View').classList.add('active');document.querySelectorAll('[data-tab],[data-bottom]').forEach(b=>b.classList.toggle('active',(b.dataset.tab||b.dataset.bottom)===name));}
function setMakes(){ $('makeInput').innerHTML=Object.keys(catalog).sort().map(m=>`<option>${m}</option>`).join(''); setModels(); }
function setModels(){const make=$('makeInput').value;$('modelOptions').innerHTML=(catalog[make]||[]).map(m=>`<option value="${m}"></option>`).join('');updateRarity();}
function updateRarity(){const r=getRarity($('modelInput').value);$('rarityPreview').textContent=`Vorgeschlagene Seltenheit: ${r.rarity}. Die endgültige Bewertung hängt von der gepflegten Modell-Datenbank ab.`;}
function safe(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function render(){vehicles.sort((a,b)=>['legendary','epic','rare','common'].indexOf(getRarity(b.model).key)-['legendary','epic','rare','common'].indexOf(getRarity(a.model).key));$('vehicleCount').textContent=`${vehicles.length.toString().padStart(2,'0')} FAHRZEUGE`;
 $('carGrid').innerHTML=vehicles.length?vehicles.map((v,i)=>`<article class="car" data-index="${i}">${v.photos?.[0]?`<img class="photo" src="${safe(v.photos[0])}" alt="${safe(v.make)} ${safe(v.model)}">`:'<div class="placeholder">FOTO</div>'}<div class="carinfo"><div class="carname">${safe(v.make)} ${safe(v.model)}</div><div class="sub">${safe(v.year||'')} ${v.photos?.length?`· ${v.photos.length} Fotos`:''}</div><span class="rarity ${getRarity(v.model).key}">${getRarity(v.model).rarity}</span></div></article>`).join(''):'<div class="empty">Deine Sammlung ist noch leer.<br>Füge dein erstes gesichtetes Auto hinzu.</div>';
 document.querySelectorAll('.car').forEach(card=>card.addEventListener('click',()=>openDetail(Number(card.dataset.index))));renderSlideshow();}
function renderSlideshow(){ $('slideCount').textContent=vehicles.length?`${slideIndex+1} / ${vehicles.length}`:'0 / 0';const v=vehicles[slideIndex];$('slideshowContent').innerHTML=v?`${v.photos?.[0]?`<img class="slide-photo" src="${safe(v.photos[0])}" alt="${safe(v.model)}">`:'<div class="empty">Kein Foto vorhanden</div>'}<div class="detail-head"><div><div class="detail-title">${safe(v.make)} ${safe(v.model)}</div><div class="sub">${safe(v.year||'')} · ${v.photos?.length||0} Fotos</div></div><span class="rarity ${getRarity(v.model).key}">${getRarity(v.model).rarity}</span></div><div class="slide-controls"><button id="prevSlide">←</button><span class="muted">Wischen oder navigieren</span><button id="nextSlide">→</button></div>`:'<div class="empty">Füge Fahrzeuge hinzu, um deine Slideshow zu starten.</div>';if(v){$('prevSlide').onclick=()=>{slideIndex=(slideIndex-1+vehicles.length)%vehicles.length;renderSlideshow();};$('nextSlide').onclick=()=>{slideIndex=(slideIndex+1)%vehicles.length;renderSlideshow();};}}
function openDetail(i){const v=vehicles[i];showView('detail');$('detailContent').innerHTML=`<div class="detail-head"><div><div class="detail-title">${safe(v.make)} ${safe(v.model)}</div><div class="sub">${safe(v.year||'')} · ${safe(v.location||'')}</div></div><span class="rarity ${getRarity(v.model).key}">${getRarity(v.model).rarity}</span></div><div class="grid">${(v.photos||[]).map(url=>`<img class="photo" style="border-radius:12px" src="${safe(url)}" alt="${safe(v.model)}">`).join('')}</div><div class="notice">${safe(v.note||'Keine Notiz hinzugefügt.')}</div>`;}
async function loadVehicles(){if(!currentUser||!db)return;try{const q=query(collection(db,'users',currentUser.uid,'vehicles'),orderBy('createdAt','desc'));const snap=await getDocs(q);vehicles=snap.docs.map(d=>({id:d.id,...d.data()}));render();}catch(e){$('authStatus').textContent='Laden fehlgeschlagen: '+e.message;}}
async function saveVehicle(e){e.preventDefault();const files=[...$('photoInput').files];if(!files.length){alert('Bitte mindestens ein Foto auswählen.');return;}const vehicle={make:$('makeInput').value,model:$('modelInput').value.trim(),year:$('yearInput').value,location:$('locationInput').value.trim(),note:$('noteInput').value.trim(),photos:[]};if(!vehicle.model){alert('Bitte ein Modell eingeben.');return;}if(!currentUser||!db||!storage){alert('Bitte zuerst Firebase konfigurieren und dich anmelden.');return;}const btn=e.submitter;btn.disabled=true;btn.textContent='Fotos werden hochgeladen …';try{for(const file of files){const path=`users/${currentUser.uid}/vehicles/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;const fileRef=ref(storage,path);await uploadBytes(fileRef,file);vehicle.photos.push(await getDownloadURL(fileRef));}await addDoc(collection(db,'users',currentUser.uid,'vehicles'),{...vehicle,createdAt:serverTimestamp()});$('addForm').reset();$('addForm').classList.add('hidden');await loadVehicles();}catch(err){alert('Speichern fehlgeschlagen: '+err.message);}finally{btn.disabled=false;btn.textContent='In Sammlung speichern';}}
function openAuth(){ $('authPanel').classList.toggle('hidden'); }
$('addBtn').onclick=()=>{$('addForm').classList.toggle('hidden');};$('bottomAdd').onclick=()=>{showView('collection');$('addForm').classList.remove('hidden');$('addForm').scrollIntoView({behavior:'smooth'});};$('cancelAdd').onclick=()=>$('addForm').classList.add('hidden');$('addForm').addEventListener('submit',saveVehicle);$('makeInput').addEventListener('change',setModels);$('modelInput').addEventListener('input',updateRarity);$('accountBtn').onclick=openAuth;$('bottomAccount').onclick=openAuth;$('backBtn').onclick=()=>showView('collection');
document.querySelectorAll('[data-tab],[data-bottom]').forEach(b=>b.addEventListener('click',()=>{const name=b.dataset.tab||b.dataset.bottom;if(name==='collection'||name==='slideshow')showView(name);}));
setMakes();
if(firebaseReady){onAuthStateChanged(auth,async user=>{currentUser=user;$('authStatus').textContent=user?`Angemeldet als ${user.email}`:'Nicht angemeldet';$('signOutBtn').classList.toggle('hidden',!user);if(user)await loadVehicles();});$('signInBtn').onclick=async()=>{try{await signInWithEmailAndPassword(auth,$('emailInput').value,$('passwordInput').value);}catch(e){$('authStatus').textContent=e.message;}};$('signUpBtn').onclick=async()=>{try{await createUserWithEmailAndPassword(auth,$('emailInput').value,$('passwordInput').value);}catch(e){$('authStatus').textContent=e.message;}};$('signOutBtn').onclick=()=>signOut(auth);}else{$('authStatus').textContent='Noch nicht verbunden: Firebase-Projekt anlegen und Konfiguration in app.js eintragen. Die Oberfläche ist lokal als Vorschau nutzbar.';$('signInBtn').disabled=true;$('signUpBtn').disabled=true;$('signOutBtn').disabled=true;}
let touchX=0;$('slideshowContent').addEventListener('touchstart',e=>touchX=e.changedTouches[0].screenX,{passive:true});$('slideshowContent').addEventListener('touchend',e=>{const dx=e.changedTouches[0].screenX-touchX;if(Math.abs(dx)>55&&vehicles.length){slideIndex=(slideIndex+(dx<0?1:-1)+vehicles.length)%vehicles.length;renderSlideshow();}},{passive:true});
if('serviceWorker' in navigator)navigator.serviceWorker.register('./sw.js').catch(()=>{});
