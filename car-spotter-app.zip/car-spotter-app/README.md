# SPOTTER – Car Spotting PWA starter

A minimal, installable iPhone-friendly web app starter. It includes a dark collection UI, a rarity-sorted vehicle gallery, a swipeable slideshow, a vehicle detail view, multi-photo upload, and Firebase Auth / Firestore / Storage integration points.

## Current status

- The UI and client-side interactions are implemented.
- Cloud saving requires your own Firebase project and configuration.
- The included vehicle list and rarity rules are an initial sample, not a complete or authoritative global vehicle database.
- The app is not deployed and is not yet installed on your iPhone.

## 1. Create Firebase project

1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web App in Project settings and copy its Firebase config.
3. Enable **Authentication → Email/Password**.
4. Create a **Cloud Firestore** database.
5. Enable **Storage**.
6. Paste the web config values into `firebaseConfig` in `app.js`.

## 2. Firestore security rules

Use rules that restrict each account to its own documents:

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/vehicles/{vehicleId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

## 3. Storage security rules

```text
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/vehicles/{fileName} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

For a production release, add upload size/type validation and stricter rules before sharing the app.

## 4. Run locally

Serve this folder over HTTPS (or localhost) with any static web server. ES modules and service workers do not work reliably from a `file://` URL. For example, with Python installed:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000` in a browser on the same machine. For iPhone testing, deploy to an HTTPS host (for example Firebase Hosting) and open the URL in Safari.

## 5. Add to iPhone Home Screen

Open the deployed HTTPS URL in Safari → Share → Add to Home Screen.

## Data model

Each vehicle is one Firestore document under `users/{uid}/vehicles/{vehicleId}`. The `photos` array stores the uploaded image URLs. Multiple photos therefore belong to one vehicle entry.
